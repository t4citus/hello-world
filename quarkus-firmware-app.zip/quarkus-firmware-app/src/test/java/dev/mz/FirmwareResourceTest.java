package dev.mz;

import dev.mz.request.DeviceInfo;
import io.quarkus.test.common.http.TestHTTPEndpoint;
import io.quarkus.test.junit.QuarkusMock;
import io.quarkus.test.junit.QuarkusTest;
import io.restassured.response.Response;
import jakarta.ws.rs.core.MediaType;
import org.apache.http.HttpStatus;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.*;

@QuarkusTest
@TestHTTPEndpoint(FirmwareResource.class)
class FirmwareResourceTest {

    private FirmwareService firmwareService;

    @BeforeEach
    public void setUp() {
        firmwareService = new FirmwareService();
    }

    @Test
    public void givenValidFirmware_whenRegisterFirmware_thenReturnsAsExpected() {
        // Given
        FirmwareInfo newFirmwareInfo = FirmwareInfo.builder()
                .hardwareId("fritz!box-6810")
                .version("2.7.1")
                .downloadUrl("http://firmware.io/6810-2.7.1.zip")
                .build();

        // When
        Response registerResponse = given()
                .contentType(MediaType.APPLICATION_JSON)
                .body(newFirmwareInfo)
                .when()
                .post("/register");

        Response getAllResponse = given().get();

        System.out.println(getAllResponse.prettyPrint());

        // Then
        Assertions.assertEquals(registerResponse.statusCode(), HttpStatus.SC_OK);
        Assertions.assertNotNull(registerResponse.jsonPath().get("message"));
        Assertions.assertEquals(getAllResponse.statusCode(), HttpStatus.SC_OK);
        Assertions.assertEquals(getAllResponse.jsonPath().getInt("count"), 1);
        Assertions.assertEquals(getAllResponse.jsonPath().getList("all", FirmwareInfo.class).get(0), newFirmwareInfo);
    }

    public void givenInvalidFirmware_whenRegisterFirmware_thenReturnsAsExpected() {
        // Given

        // When

        // Then
    }

    @Test
    public void givenDeviceInfoWithUnsupportedHardwareId_whenVerifyFirmware_thenReturnsAsExpected() {
        // Given
        DeviceInfo deviceInfo = DeviceInfo.builder()
                .hardwareId("<UNSUPPORTED>")
                .firmwareVersion("1.5")
                .build();

        // When
        Response verifyResponse = given()
                .contentType(MediaType.APPLICATION_JSON)
                .body(deviceInfo)
                .when()
                .post("/verify");

        // Then
        verifyResponse.then()
                .statusCode(HttpStatus.SC_OK)
                .body("isUpdateAvailable", is(false))
                .body("message", is("No firmware available for this hardware."));
    }

    @Test
    public void givenDeviceInfoWithOutdatedFirmwareVersion_whenVerifyFirmware_thenReturnsAsExpected() {
        // Given
        DeviceInfo deviceInfo = DeviceInfo.builder()
                .hardwareId("fritz!box-5490")
                .firmwareVersion("1.5")
                .build();

        // Upload compatible but newer firmware version
        FirmwareInfo latestFirmware = FirmwareInfo.builder()
                .hardwareId("fritz!box-5490")
                .version("1.6")
                .downloadUrl("http://firmware.io/5490-1.6.zip")
                .build();

        given().contentType(MediaType.APPLICATION_JSON)
                .body(latestFirmware)
                .when()
                .post("/register");

        // When
        Response verifyResponse = given()
                .contentType(MediaType.APPLICATION_JSON)
                .body(deviceInfo)
                .when()
                .post("/verify");

        // Then
        verifyResponse.then()
                .statusCode(HttpStatus.SC_OK)
                .body("isUpdateAvailable", is(true))
                .body("newVersion", is("1.6"))
                .body("downloadUrl", is("http://firmware.io/5490-1.6.zip"))
                .body("currentVersion", is("1.5"))
                .body("message", is("Newer firmware available."));
    }

    public void givenDeviceInfoWithCurrentFirmwareVersion_whenVerifyFirmware_thenReturnsAsExpected() {
        // Given

        // When

        // Then
    }

    @Test
    public void givenNoRegisteredFirmwares_whenGetFirmwares_thenReturnsEmptyList() {
        // Given

        // When
        Response response = given().when().get();

        // Then
        response
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("all", is(List.of()))
                .body("count", is(0));
    }

    @Test
    public void givenRegisteredFirmwares_whenGetFirmwares_thenReturnsList() {
        // Given
        List<FirmwareInfo> firmwares = List.of(
                new FirmwareInfo("fritz!box-5490", "1.9", "http://firmware.io/5490-1.9.zip"),
                new FirmwareInfo("fritz!box-6840", "2.0.5", "http://firmware.io/6840-2.0.5.zip"),
                new FirmwareInfo("fritz!box-5590", "7.1", "http://firmware.io/5590-7.1.zip")
        );

        for (FirmwareInfo firmwareInfo : firmwares) {
            given().contentType(MediaType.APPLICATION_JSON)
                    .body(firmwareInfo)
                    .when()
                    .post("/register");
        }

        // When
        Response response = given().when().get();

        // Then
        List<FirmwareInfo> responseBodyFirmwares = response
                .then()
                .statusCode(HttpStatus.SC_OK)
                .body("count", is(3))
                .extract()
                .jsonPath().getList("all", FirmwareInfo.class);

        Assertions.assertEquals(firmwares.size(), responseBodyFirmwares.size());
        Assertions.assertTrue(firmwares.containsAll(responseBodyFirmwares));
        Assertions.assertTrue(responseBodyFirmwares.containsAll(firmwares));
    }
}