package dev.mz.request;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class DeviceInfo {
    private String hardwareId;
    private String firmwareVersion;
}
