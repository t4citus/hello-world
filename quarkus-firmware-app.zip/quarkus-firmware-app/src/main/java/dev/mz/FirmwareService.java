package dev.mz;

import jakarta.enterprise.context.ApplicationScoped;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ApplicationScoped
public class FirmwareService {

    private final Map<String, FirmwareInfo> latestFirmwareCache = new HashMap<>();

    public void addFirmware(FirmwareInfo firmwareInfo) {
        latestFirmwareCache.put(firmwareInfo.getHardwareId(), firmwareInfo);
    }

    public List<FirmwareInfo> getFirmwareList() {
        return latestFirmwareCache.values().stream().toList();
    }

    public FirmwareInfo getFirmwareByHardwareId(String hardwareId) {
        return latestFirmwareCache.get(hardwareId);
    }

    public void clear() {
        latestFirmwareCache.clear();
    }
}
