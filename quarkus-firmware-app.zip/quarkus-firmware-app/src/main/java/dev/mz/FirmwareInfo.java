package dev.mz;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Builder
@EqualsAndHashCode
@ToString
public class FirmwareInfo {
    private String hardwareId;
    private String version;
    private String downloadUrl;
}
