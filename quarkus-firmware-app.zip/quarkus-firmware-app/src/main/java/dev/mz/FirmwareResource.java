package dev.mz;

import dev.mz.request.DeviceInfo;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

import java.util.List;
import java.util.Map;

@Path("/api/firmware")
public class FirmwareResource {

    private final FirmwareService firmwareService;

    public FirmwareResource(FirmwareService firmwareService) {
        this.firmwareService = firmwareService;
    }

    @POST
    @Path("/verify")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response verifyFirmware(DeviceInfo deviceInfo) {
        final String hardwareId = deviceInfo.getHardwareId();
        final String firmwareVersion = deviceInfo.getFirmwareVersion();

        final FirmwareInfo latestFirmware = firmwareService.getFirmwareByHardwareId(hardwareId);

        if (latestFirmware == null) {
            return Response.ok(Map.of(
                    "isUpdateAvailable", false,
                    "message", "No firmware available for this hardware."))
                    .build();
        }

        if (latestFirmware.getVersion().equals(firmwareVersion)) {
            return Response.ok(Map.of(
                            "isUpdateAvailable", false,
                            "message", "Latest firmware version already installed."))
                    .build();
        }

        return Response.ok(Map.of(
                        "isUpdateAvailable", true,
                        "newVersion", latestFirmware.getVersion(),
                        "downloadUrl", latestFirmware.getDownloadUrl(),
                        "installedVersion", firmwareVersion,
                        "message", "Newer firmware available."))
                .build();
    }

    @POST
    @Path("/register")
    public Response registerFirmware(FirmwareInfo firmwareInfo) {
        firmwareService.addFirmware(firmwareInfo);
        return Response.ok(Map.of(
                        "message", "New firmware registered."))
                .build();
    }

    @GET
    @Path("")
    public Response listFirmware() {
        List<FirmwareInfo> firmwares = firmwareService.getFirmwareList();
        if (firmwares == null) firmwares = List.of();

        return Response.ok(Map.of(
                "all", firmwares,
                "count", firmwares.size()
                ))
                .build();
    }
}
