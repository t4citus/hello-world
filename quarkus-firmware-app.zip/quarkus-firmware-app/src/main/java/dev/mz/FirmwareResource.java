package dev.mz;

import dev.mz.request.DeviceInfo;
import io.netty.handler.codec.http.HttpResponseStatus;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

import java.util.List;
import java.util.Map;

@Tag(name = "Firmware Resource", description = "Firmware REST APIs")
@Path("/api/firmware")
public class FirmwareResource {

    private final FirmwareService firmwareService;

    public FirmwareResource(FirmwareService firmwareService) {
        this.firmwareService = firmwareService;
    }

    @Operation(summary = "Verifies the firmware of the incoming device info.")
    @APIResponses(value = {
        @APIResponse(responseCode = "400", description = "Invalid payload"),
        @APIResponse(responseCode = "200", description = "Successful verification")
    })
    @POST
    @Path("/verify")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response verifyFirmware(DeviceInfo deviceInfo) {
        if (deviceInfo == null || isNullOrEmpty(deviceInfo.getHardwareId())) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        String hardwareId = deviceInfo.getHardwareId();
        String firmwareVersion = deviceInfo.getFirmwareVersion();

        FirmwareInfo latestFirmware = firmwareService.getFirmwareByHardwareId(hardwareId);

        if (latestFirmware == null) {
            return Response.ok(Map.of(
                    "isUpdateAvailable", false,
                    "message", "No firmware available for this hardware."))
                    .build();
        }

        if (latestFirmware.getFirmwareVersion().equals(firmwareVersion)) {
            return Response.ok(Map.of(
                            "isUpdateAvailable", false,
                            "message", "Latest firmware version already installed."))
                    .build();
        }

        return Response.ok(Map.of(
                        "isUpdateAvailable", true,
                        "newVersion", latestFirmware.getFirmwareVersion(),
                        "downloadUrl", latestFirmware.getDownloadUrl(),
                        "currentVersion", firmwareVersion,
                        "message", "Newer firmware available."))
                .build();
    }

    @Operation(summary = "Registers a new firmware for a specific hardwareId.")
    @APIResponses(value = {
            @APIResponse(responseCode = "400", description = "Invalid payload"),
            @APIResponse(responseCode = "200", description = "Successful registration")
    })
    @POST
    @Path("/register")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response registerFirmware(FirmwareInfo firmwareInfo) {
        if (firmwareInfo == null
                || isNullOrEmpty(firmwareInfo.getHardwareId())
                || isNullOrEmpty(firmwareInfo.getFirmwareVersion())
                || isNullOrEmpty(firmwareInfo.getDownloadUrl())) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        firmwareService.addFirmware(firmwareInfo);
        return Response.ok(Map.of(
                        "message", "New firmware registered."))
                .build();
    }

    @Operation(summary = "Lists all registered firmwares.")
    @APIResponses(value = {
            @APIResponse(responseCode = "200", description = "Returns the list.")
    })
    @GET
    @Path("")
    @Produces(MediaType.APPLICATION_JSON)
    public Response listFirmware() {
        List<FirmwareInfo> firmwares = firmwareService.getFirmwareList();
        if (firmwares == null) firmwares = List.of();

        return Response.ok(Map.of(
                "all", firmwares,
                "count", firmwares.size()
                ))
                .build();
    }

    private static boolean isNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }
}
