package dev.mz.response;

public enum VerificationCode {
    NO_FIRMWARE_AVAILABLE,
    FIRMWARE_UP_TO_DATE,
    NEWER_FIRMWARE_AVAILABLE
}
