# quarkus-firmware-app

This project provides a REST service to maintain the verification and 
registration of device firmwares. The service provides three main services:

### 1. Verification Endpoint (/api/firmware/verify)

The verification endpoint is used to check if the firmware for a specific hardware requires an update.

### 2. Registration Endpoint (/api/firmware/register)

The registration endpoint is used to register a new firmware for a specific hardware
(identified by its hardware id).

### 3. List Endpoint (/api/firmware)

The list endpoint returns a list of all registered firmwares.

### Setup

- [Java 21](https://adoptium.net/de/temurin/releases/)
- [Quarkus](https://code.quarkus.io/)
- Bundled with [Maven](https://maven.apache.org/) (mvnw)
- Swagger UI (http://localhost:8282/q/swagger-ui/)
- Docker setup can be <ins>ignored</ins> for now

### Running the application in dev mode

```shell script
./mvnw compile quarkus:dev
```

### Packaging and running the application

```shell script
./mvnw package
```